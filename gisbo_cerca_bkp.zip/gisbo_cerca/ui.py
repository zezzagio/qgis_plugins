# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'ui.ui'
#
# Created: Mon Dec 01 12:04:18 2014
#      by: PyQt4 UI code generator 4.10.2
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_Dialog(object):
    def setupUi(self, Dialog):
        Dialog.setObjectName(_fromUtf8("Dialog"))
        Dialog.resize(328, 357)
        self.verticalLayout = QtGui.QVBoxLayout(Dialog)
        self.verticalLayout.setObjectName(_fromUtf8("verticalLayout"))
        self.label_3 = QtGui.QLabel(Dialog)
        self.label_3.setObjectName(_fromUtf8("label_3"))
        self.verticalLayout.addWidget(self.label_3)
        self.layer_da_cercare = QtGui.QComboBox(Dialog)
        self.layer_da_cercare.setObjectName(_fromUtf8("layer_da_cercare"))
        self.verticalLayout.addWidget(self.layer_da_cercare)
        self.criterio_ricerca = QtGui.QGroupBox(Dialog)
        sizePolicy = QtGui.QSizePolicy(QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Expanding)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.criterio_ricerca.sizePolicy().hasHeightForWidth())
        self.criterio_ricerca.setSizePolicy(sizePolicy)
        self.criterio_ricerca.setMinimumSize(QtCore.QSize(0, 0))
        self.criterio_ricerca.setAlignment(QtCore.Qt.AlignLeading|QtCore.Qt.AlignLeft|QtCore.Qt.AlignVCenter)
        self.criterio_ricerca.setObjectName(_fromUtf8("criterio_ricerca"))
        self.horizontalLayout = QtGui.QHBoxLayout(self.criterio_ricerca)
        self.horizontalLayout.setObjectName(_fromUtf8("horizontalLayout"))
        self.per_id = QtGui.QRadioButton(self.criterio_ricerca)
        sizePolicy = QtGui.QSizePolicy(QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Preferred)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.per_id.sizePolicy().hasHeightForWidth())
        self.per_id.setSizePolicy(sizePolicy)
        self.per_id.setChecked(True)
        self.per_id.setObjectName(_fromUtf8("per_id"))
        self.horizontalLayout.addWidget(self.per_id)
        self.per_ug = QtGui.QRadioButton(self.criterio_ricerca)
        sizePolicy = QtGui.QSizePolicy(QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Expanding)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.per_ug.sizePolicy().hasHeightForWidth())
        self.per_ug.setSizePolicy(sizePolicy)
        self.per_ug.setChecked(False)
        self.per_ug.setObjectName(_fromUtf8("per_ug"))
        self.horizontalLayout.addWidget(self.per_ug)
        self.per_area = QtGui.QRadioButton(self.criterio_ricerca)
        sizePolicy = QtGui.QSizePolicy(QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Expanding)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.per_area.sizePolicy().hasHeightForWidth())
        self.per_area.setSizePolicy(sizePolicy)
        self.per_area.setObjectName(_fromUtf8("per_area"))
        self.horizontalLayout.addWidget(self.per_area)
        self.verticalLayout.addWidget(self.criterio_ricerca)
        self.label = QtGui.QLabel(Dialog)
        self.label.setObjectName(_fromUtf8("label"))
        self.verticalLayout.addWidget(self.label)
        self.elementi_da_cercare = QtGui.QPlainTextEdit(Dialog)
        self.elementi_da_cercare.setObjectName(_fromUtf8("elementi_da_cercare"))
        self.verticalLayout.addWidget(self.elementi_da_cercare)
        self.label_2 = QtGui.QLabel(Dialog)
        self.label_2.setObjectName(_fromUtf8("label_2"))
        self.verticalLayout.addWidget(self.label_2)
        self.messaggi = QtGui.QPlainTextEdit(Dialog)
        self.messaggi.setObjectName(_fromUtf8("messaggi"))
        self.verticalLayout.addWidget(self.messaggi)
        self.buttonBox = QtGui.QDialogButtonBox(Dialog)
        self.buttonBox.setOrientation(QtCore.Qt.Horizontal)
        self.buttonBox.setStandardButtons(QtGui.QDialogButtonBox.Cancel|QtGui.QDialogButtonBox.Ok|QtGui.QDialogButtonBox.Reset)
        self.buttonBox.setCenterButtons(True)
        self.buttonBox.setObjectName(_fromUtf8("buttonBox"))
        self.verticalLayout.addWidget(self.buttonBox)

        self.retranslateUi(Dialog)
        QtCore.QObject.connect(self.buttonBox, QtCore.SIGNAL(_fromUtf8("rejected()")), Dialog.reject)
        QtCore.QMetaObject.connectSlotsByName(Dialog)

    def retranslateUi(self, Dialog):
        Dialog.setWindowTitle(_translate("Dialog", "Ricerca sul GIS di Bologna", None))
        self.label_3.setText(_translate("Dialog", "Layer in cui cercare:", None))
        self.criterio_ricerca.setTitle(_translate("Dialog", "Criterio di ricerca", None))
        self.per_id.setText(_translate("Dialog", "Per codice elemento", None))
        self.per_ug.setText(_translate("Dialog", "Per u.g.", None))
        self.per_area.setText(_translate("Dialog", "Per codice area", None))
        self.label.setText(_translate("Dialog", "Codici elementi da cercare:", None))
        self.label_2.setText(_translate("Dialog", "Che cosa ne penso:", None))

