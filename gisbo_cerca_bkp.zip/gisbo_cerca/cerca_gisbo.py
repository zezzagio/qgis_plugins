﻿#! /usr/bin/env python
# emacs-mode: -*- python-*-
# -*- coding: utf-8 -*-

import sys 
import re
import errno
sys.path.append('/usr/share/qgis/python')
from PyQt4.QtCore import * 
from PyQt4.QtGui import * 
from qgis.core import * 
from qgis.gui import * 
from ui_control import ui_Control
import psycopg2
import resources 
import os

class cerca_gisbo(object):
    """
    """
    def __init__(self, iface):
        self.iface = iface
        self.canvas = iface.mapCanvas()
        self.fPath = ''
        self.ultima_ricerca = ''
        self.host = 'verde06'
        self.dbname = 'postgis'
        self.conn_string = "host='{0}' dbname='{1}' port='5432' user='bologna' password='bologna'".format(self.host, self.dbname)
        self.pluginGui = ui_Control(self.iface.mainWindow())
        self.messaggi = self.pluginGui.messaggi
        
    def initGui(self):
        self.action = QAction(QIcon(":/plugins/gisbo_cerca/magnifier11.png"), 'Ricerche in GIS Bologna', self.iface.mainWindow())
        self.action.setWhatsThis('Ricerche in GIS Bologna')
        self.iface.addToolBarIcon(self.action)

        self.readConf()
        
        QObject.connect(self.action, SIGNAL('activated()'), self.run)
        
        self.iface.addPluginToMenu('Cerca &GIS Bologna', self.action)
        
        buttonBox = self.pluginGui.buttonBox
        QObject.connect(buttonBox.button(QDialogButtonBox.Reset),SIGNAL("clicked()"),self.messaggi.clear)
        QObject.connect(buttonBox.button(QDialogButtonBox.Ok),SIGNAL("clicked()"),self.ricerca)

    def unload(self):
        self.iface.removePluginMenu('Cerca &GIS Bologna', self.action)
        self.iface.removeToolBarIcon(self.action)
        self.saveConf()

    def run(self):
        ls_temi = self.pluginGui.layer_da_cercare
        if ls_temi.currentIndex() >= 0:
            self.ultima_ricerca = ls_temi.currentText()
        try:
            connection = psycopg2.connect(self.conn_string)
            temi_query = connection.cursor()
            
            sql = """SELECT substring(tabella_postgis from '[^.]+$'),
            array[codice_elemento, ref_ug, tabella_ug, tabella_postgis] as data
            FROM bologna.lista_temi
            WHERE processa and codice_elemento IS NOT NULL
            ORDER BY tabella_postgis
            """

            temi_query.execute(sql)

            ls_temi.clear()

            for tema in temi_query:
                ls_temi.addItem(tema[0], tema[1])
            temi_query.close()
            connection.close()
        except Exception, e:
            self.tell(repr(e))

        ndx_layer = ls_temi.findText(self.ultima_ricerca)
        if (ndx_layer > 0):
            ls_temi.setCurrentIndex(ndx_layer)
        buttonBox = self.pluginGui.buttonBox
        buttonBox.button(QDialogButtonBox.Reset).setText('Cancella messaggi')
        self.pluginGui.show()
        self.pluginGui.repaint()

    def dividi_codici(self, pattern):
        lista_codici = re.findall(pattern, self.pluginGui.elementi_da_cercare.toPlainText())
        return lista_codici
        
    def esplodi_codici(self):
        codici = self.pluginGui.elementi_da_cercare.toPlainText()
        lista_pezzi = re.findall(r'([\d-]+)', codici)
        lista_codici = set()
        for p in lista_pezzi:
            if p == '-':
                continue
            codici = p.split('-')
            prefisso = codici[0]
            lung_pref = len(prefisso)
            for c in codici:
                lung_c = len(c)
                if lung_c < lung_pref:
                    lista_codici.add(prefisso[0:lung_pref - lung_c] + c)
                else:
                    lista_codici.add(c)
        return sorted(lista_codici, key=int)

    def cerca_layer(self, schema, nome_layer):
        legenda = self.iface.legendInterface()
        layers = legenda.layers()
        layer = None
        sql = None
        gid = None
        geom = None
        for cerca in layers:
            try:
                uri = QgsDataSourceURI(cerca.dataProvider().dataSourceUri())
            except:
                continue
            if (uri.host().lower() == self.host.lower() and
                uri.database().lower() == self.dbname.lower() and
                (not uri.schema() or uri.schema().lower() == schema.lower()) and
                uri.table().lower() == nome_layer.lower()):
                layer = cerca
                gid = uri.keyColumn()
                geom = uri.geometryColumn()
                if uri.sql():
                    sql = '(' + uri.sql() + ')'
                break
        return (layer, sql, gid, geom)

    def seleziona_elementi(self, layer, list_gid):
        layer.setSelectedFeatures(list_gid)
        self.tell('<font color=blue>Trovati ' + str(len(list_gid)) + ' elementi</font>')
        list_sel_gid = layer.selectedFeatures()
        if not list_sel_gid:
            layer.removeSelection()
            self.tell('<font color=red>' + str(len(list_gid)) + ' elementi filtrati</font>')

    def ricerca(self):
        ls_temi = self.pluginGui.layer_da_cercare
        ndx_layer = ls_temi.currentIndex()
        dati_layer = ls_temi.itemData(ndx_layer) 
        #nome_tabella = ls_temi.itemText(ndx_layer)
        nome_tabella = dati_layer[3]
        [schema, nome_layer] = re.split('\.', nome_tabella)
        nome_id = dati_layer[0]
        ref_ug = dati_layer[1]
        tabella_ug = dati_layer[2]

        (layer, filtro, nome_gid, nome_geom) = self.cerca_layer(schema, nome_layer)

        if (not layer):
            self.tell("<b>Il layer: </b><font color=red>" + nome_layer + u"</font> non è presente")
            return

        if (self.pluginGui.per_id.isChecked()):
            nome_campo = nome_id
            lista_codici = self.esplodi_codici()
        elif (self.pluginGui.per_ug.isChecked()):
            nome_campo = ref_ug
            lista_codici = self.dividi_codici('(\d+)')
        else:
            nome_campo = 'cod_pre'
            lista_codici = self.dividi_codici('(\w+)')
            lista_codici = ["'" + cod + "'" for cod in lista_codici]

        if not lista_codici:
            self.tell('<font color=red><b>Ricerca non valida!</b></font>')
            return
            
        insieme_codici = ", ".join(lista_codici)
        self.tell("<b>Ricerca sul layer: </b><font color=green>" + nome_layer + "</font>")
        self.tell("<i>Obiettivo: </i><font color=green>" + nome_campo + " in (" + insieme_codici + ")</font>")
        try:
            
            connection = psycopg2.connect(self.conn_string)

            sql_org = """SELECT array_agg({0}) as list_gid,
            st_astext(st_extent({1})) as extent
            FROM """.format(nome_gid, nome_geom) + nome_tabella + " AS o"

            sql = sql_org

            if (self.pluginGui.per_area.isChecked() and tabella_ug):
                sql += " LEFT JOIN " + tabella_ug + " AS a ON o." + ref_ug
                sql += " = a.cod_ug"

            where_clause = "(" + nome_campo + " in (" + insieme_codici + "))"
            
            sql += " WHERE " + where_clause

            sql = sql.encode('utf8')

            feat_query = connection.cursor()
            feat_query.execute(sql)
            box = QgsRectangle(0, 0, 0, 0)
                
            feat = feat_query.fetchone()
            list_gid = feat[0]
            extent = feat[1]
            feat_query.close()
            
            if (list_gid):
                if not filtro:
                    self.seleziona_elementi(layer, list_gid)
                else:
                    insieme_id = ', '.join([str(gid) for gid in list_gid])
                    sql = sql_org + " WHERE " + filtro + " AND ({0} in (".format(nome_gid) + insieme_id + "))"
                    sql = sql.encode('utf8')

                    feat_query = connection.cursor()
                    feat_query.execute(sql)
                    feat = feat_query.fetchone()
                    list_gid = feat[0]
                    extent = feat[1]
                    feat_query.close()
                    
                    if (list_gid):
                        self.seleziona_elementi(layer, list_gid)
                        
            if (extent):
                box = QgsGeometry.fromWkt(extent).boundingBox()
                if (box):
                    self.canvas.setExtent(box)
                    self.canvas.refresh()
            else:
                self.tell(u'<font color=red>Non è stato trovato nessun elemento</font>')
                
            if ndx_layer >= 0:
                self.ultima_ricerca = ls_temi.itemText(ndx_layer)
                
            connection.close()
        except RuntimeError, e:
            self.tell(u'<br><h2><font color=red>Qualcosa è andato storto!</font></h2>')
            self.tell('<br><font color=blue>' + sql + '</font>')
            self.tell('<br><font color=green>' + e + '</font>')
        except Exception, e:
            self.tell('<br><font color=blue>' + sql + '</font>')
            self.tell('<br><font color=red>' + repr(e) + '</font>')
            
    def tell(self, txt):
        self.messaggi.appendHtml(txt)
        
    def saveConf(self):
        settings = QSettings()
        settings.setValue('/cerca_gisbo/ultima_ricerca', self.ultima_ricerca)
        
    def readConf(self):
        settings = QSettings()
        self.ultima_ricerca = settings.value('/cerca_gisbo/ultima_ricerca', 'alberi')
      
      
