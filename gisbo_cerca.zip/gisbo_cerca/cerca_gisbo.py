﻿#! /usr/bin/env python
# emacs-mode: -*- python-*-
# -*- coding: utf-8 -*-

import sys 
import re
import errno
sys.path.append('/usr/share/qgis/python')
from PyQt5.QtCore import * 
from PyQt5.QtGui import * 
from PyQt5.QtWidgets import * 
from qgis.core import * 
from qgis.gui import * 
from .ui_control import ui_Control
import psycopg2
from .resources import *
from .imposta_parametri_connessione import ImpostaParametriConnessione
import os

class cerca_gisbo(object):
    """
    """
    def __init__(self, iface):
        self.iface = iface
        self.canvas = iface.mapCanvas()
        settings = QSettings()
        self.leggi_parametri_connessione(1)
        self.pluginGui = ui_Control(self.iface.mainWindow())
        self.messaggi = self.pluginGui.messaggi
        self.parametri_connessione = ImpostaParametriConnessione(self.iface.mainWindow())
        
    def initGui(self):
        self.action = QAction(QIcon(":/plugins/gisbo_cerca/magnifier11.png"), 'Ricerche in GIS Bologna', self.iface.mainWindow())
        self.action.setWhatsThis('Ricerche in GIS Bologna')
        self.iface.addToolBarIcon(self.action)

        self.action.triggered.connect(self.run)
        
        self.action1 = QAction(QIcon(":/plugins/gisbo_cerca/script.png"), 'Elenco selezionati', self.iface.mainWindow())
        self.action1.setWhatsThis('Ricerche in GIS Bologna')
        self.iface.addToolBarIcon(self.action1)
        
        self.action1.triggered.connect(self.elenco_selezionati)
        
        self.iface.addPluginToMenu('Cerca &GIS Bologna', self.action)
        
        buttonBox = self.pluginGui.buttonBox
        buttonBox.button(QDialogButtonBox.Reset).clicked.connect(self.messaggi.clear)
        buttonBox.button(QDialogButtonBox.Ok).clicked.connect(self.ricerca)
        buttonBox.button(QDialogButtonBox.Open).clicked.connect(self.imposta_connessione)

    def imposta_connessione(self):
        self.parametri_connessione.parametriCambiati.connect(self.leggi_parametri_connessione)
        self.parametri_connessione.run()
        self.parametri_connessione.parametriCambiati.disconnect(self.leggi_parametri_connessione)
        
    def leggi_parametri_connessione(self, aggiorna):
        if aggiorna:
            settings = QSettings()
            self.host = settings.value('cerca_gisbo/host', 'localhost')
            self.dbname = settings.value('cerca_gisbo/database', 'postgis')
            self.port = settings.value('cerca_gisbo/port', '5432')
            self.auth_cfg_id = settings.value('cerca_gisbo/auth_cfg_id', '')
        if aggiorna == 2:
            self.leggi_layers()

    def connettiPg(self):
        auth_mgr = QgsApplication.authManager()
        auth_cfg = QgsAuthMethodConfig()
        auth_mgr.loadAuthenticationConfig(self.auth_cfg_id, auth_cfg, True)
        auth_par = auth_cfg.configMap()
        try:
            connection = psycopg2.connect(
                host = self.host,
                database = self.dbname,
                port = self.port,
                user = auth_par['username'],
                password = auth_par['password'],
                connect_timeout = 3)
        except Exception as e:
            self.tell(repr(e))
        return connection
        
    def unload(self):
        self.iface.removePluginMenu('Cerca &GIS Bologna', self.action)
        self.iface.removeToolBarIcon(self.action)
        self.iface.removeToolBarIcon(self.action1)
        self.saveConf()

    def leggi_layers(self):
        ls_temi = self.pluginGui.layer_da_cercare
        ultima_ricerca = ls_temi.currentText()
        try:
            connection = self.connettiPg()
            temi_query = connection.cursor()
             
            sql = """SELECT tema,
            array[codice_elemento, ref_ug, tabella_ug, tabella_postgis] as data
            FROM bologna.lista_temi
            WHERE processa and codice_elemento IS NOT NULL
            ORDER BY tabella_postgis
            """
 
            temi_query.execute(sql)
 
            ls_temi.clear()
 
            for tema in temi_query:
                ls_temi.addItem(tema[0], tema[1])
            temi_query.close()
            connection.close()
        except Exception as e:
            ls_temi.clear()
            self.tell(repr(e))

        ndx_layer = ls_temi.findText(ultima_ricerca)
        if (ndx_layer > 0):
            ls_temi.setCurrentIndex(ndx_layer)
        
    def run(self):
        self.leggi_layers()
        buttonBox = self.pluginGui.buttonBox
        buttonBox.button(QDialogButtonBox.Reset).setText('Cancella messaggi')
        buttonBox.button(QDialogButtonBox.Open).setText('Modifica connessione')
        self.pluginGui.show()
        self.pluginGui.repaint()

    def dividi_codici(self, pattern):
        lista_codici = re.findall(pattern, self.pluginGui.elementi_da_cercare.toPlainText())
        return lista_codici
        

    def cerca_gid(self, nome_layer):
        try:
            
            connection = self.connettiPg()
            temi_query = connection.cursor()
            
            
            sql = """SELECT codice_elemento
            FROM bologna.lista_temi
            WHERE processa AND codice_elemento IS NOT NULL
            AND lower(tema) = lower('{0}')
            """.format(nome_layer)


            temi_query.execute(sql)

            rec = temi_query.fetchone()

            return rec[0]
        except:
            return None
    def cerca_layer(self, schema, nome_layer):
        layers = self.iface.mapCanvas().layers()
        layer = None
        sql = None
        gid = None
        geom = None
        
        for cerca in layers:
            #try:
            uri = QgsDataSourceUri(cerca.dataProvider().dataSourceUri())
            #except:
            if (uri.database().lower() == self.dbname.lower() and
                (not uri.schema() or uri.schema().lower() == schema.lower()) and
                uri.table().lower() == nome_layer.lower()):
                layer = cerca
                gid = uri.keyColumn()
                geom = uri.geometryColumn()
                if uri.sql():
                    sql = '(' + uri.sql() + ')'
                break
        return (layer, sql, gid, geom)

    def seleziona_elementi(self, layer, list_gid):
        layer.selectByIds(list_gid)
        self.tell('<font color=blue>Trovati ' + str(len(list_gid)) + ' elementi</font>')
        list_sel_gid = layer.selectedFeatures()
        if not list_sel_gid:
            layer.removeSelection()
            self.tell('<font color=red>' + str(len(list_gid)) + ' elementi filtrati</font>')

    def ricerca(self):
        ls_temi = self.pluginGui.layer_da_cercare
        ndx_layer = ls_temi.currentIndex()
        dati_layer = ls_temi.itemData(ndx_layer) 
        #nome_tabella = ls_temi.itemText(ndx_layer)
        nome_tabella = dati_layer[3]
        [schema, nome_layer] = re.split('\.', nome_tabella)
        nome_id = dati_layer[0]
        ref_ug = dati_layer[1]
        tabella_ug = dati_layer[2]

        (layer, filtro, nome_gid, nome_geom) = self.cerca_layer(schema, nome_layer)

        if (not layer):
            self.tell("<b>Il layer: </b><font color=red>" + nome_layer + u"</font> non è presente")
            return

        if (self.pluginGui.per_id.isChecked()):
            nome_campo = nome_id
            lista_codici = self.dividi_codici('(\\d+)')
        elif (self.pluginGui.per_ug.isChecked()):
            nome_campo = ref_ug
            lista_codici = self.dividi_codici('(\\d+)')
        else:
            nome_campo = 'cod_pre'
            lista_codici = self.dividi_codici('(\\w+)')
            lista_codici = ["'" + cod + "'" for cod in lista_codici]

        if not lista_codici:
            self.tell('<font color=red><b>Ricerca non valida!</b></font>')
            return
            
        insieme_codici = ", ".join(lista_codici)
        self.tell("<b>Ricerca sul layer: </b><font color=green>" + nome_layer + "</font>")
        self.tell("<i>Obiettivo: </i><font color=green>" +
            nome_campo +
            " in (" + insieme_codici + ")</font>")
        self.tell("<i>Numero elementi ricercati: </i><font color=green>" + str(len(lista_codici)) + "</font>")
        try:
            
            connection = self.connettiPg()

            sql_org = """SELECT array_agg({0}) as list_gid,
            st_astext(st_extent({1})) as extent
            FROM """.format(nome_gid, nome_geom) + nome_tabella + " AS o"

            sql = sql_org

            if (self.pluginGui.per_area.isChecked() and tabella_ug):
                sql += " LEFT JOIN " + tabella_ug + " AS a ON o." + ref_ug
                sql += " = a.cod_ug"

            where_clause = "(" + nome_campo + " in (" + insieme_codici + "))"
            
            sql += " WHERE " + where_clause

            sql = sql.encode('utf8')

            feat_query = connection.cursor()
            feat_query.execute(sql)
            box = QgsRectangle(0, 0, 0, 0)
                
            feat = feat_query.fetchone()
            list_gid = feat[0]
            extent = feat[1]
            feat_query.close()
            
            if (list_gid):
                if not filtro:
                    self.seleziona_elementi(layer, list_gid)
                else:
                    insieme_id = ', '.join([str(gid) for gid in list_gid])
                    sql = sql_org + " WHERE " + filtro + " AND ({0} in (".format(nome_gid) + insieme_id + "))"
                    sql = sql.encode('utf8')

                    feat_query = connection.cursor()
                    feat_query.execute(sql)
                    feat = feat_query.fetchone()
                    list_gid = feat[0]
                    extent = feat[1]
                    feat_query.close()
                    
                    if (list_gid):
                        self.seleziona_elementi(layer, list_gid)
                        
            if (extent):
                box = QgsGeometry.fromWkt(extent).boundingBox()
                if (box):
                    self.canvas.setExtent(box)
                    self.canvas.refresh()
            else:
                self.tell(u'<font color=red>Non è stato trovato nessun elemento</font>')
                
            connection.close()
        except RuntimeError as e:
            self.tell(u'<br><h2><font color=red>Qualcosa è andato storto!</font></h2>')
            self.tell('<br><font color=blue>' + sql + '</font>')
            self.tell('<br><font color=green>' + e + '</font>')
        except Exception as e:
            self.tell('<br><font color=blue>' + sql + '</font>')
            self.tell('<br><font color=red>' + repr(e) + '</font>')
            
    def elenco_selezionati(self):
        layer = self.iface.activeLayer()
        try:
            selection = layer.selectedFeatures()
            nome_layer = QgsDataSourceUri(layer.dataProvider().dataSourceUri()).table()
            nome_gid  = self.cerca_gid(nome_layer)
            if nome_gid is None:
                ids = sorted([feature.id() for feature in selection])
            else:
                ids =sorted([feature[nome_gid] for feature in selection]) 
            elenco = ', '.join([str(id) for id in ids])
            QgsApplication.clipboard().setText(elenco, QClipboard.Clipboard)
        except:
            QgsApplication.clipboard().setText('nulla di fatto', QClipboard.Clipboard)
            pass
    def tell(self, txt):
        self.messaggi.appendHtml(txt)
        
    
    def saveConf(self):
        settings = QSettings()
        settings.setValue('cerca_gisbo/host', self.host)
        settings.setValue('cerca_gisbo/port', self.port)
        settings.setValue('cerca_gisbo/database', self.dbname)
        settings.setValue('cerca_gisbo/auth_cfg_id', self.auth_cfg_id)
        