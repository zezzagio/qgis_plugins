from PyQt5.QtCore import *
from PyQt5.QtGui import *
from PyQt5.QtWidgets import *

from .ui import Ui_Dialog


class ui_Control(QDialog, Ui_Dialog):
    def __init__(self, parent):
        QDialog.__init__(self, parent)
        self.setupUi(self)

if __name__=="__main__":
    import sys,os
    app=QApplication(sys.argv)
    c=ui_Control(None)
    c.show()
    sys.exit(app.exec_())
