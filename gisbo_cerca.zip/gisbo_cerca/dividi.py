#! /usr/bin/python
import regex

def dividi_codici(codici):
    codici = regex.sub(r'\(([^()]|(?R))*\)', '', codici)
    codici = regex.sub(r'\[([^\[\]]|(?R))*\]', '', codici)
    print '>>>'
    print codici
    lista_pezzi = regex.findall(r'([\d-]+)', codici)
    lista_codici = set()
    for p in lista_pezzi:
        if p == '-':
            continue
        codici = p.split('-')
        prefisso = codici[0]
        lung_pref = len(prefisso)
        for c in codici:
            lung_c = len(c)
            if lung_c < lung_pref:
                lista_codici.add(prefisso[0:lung_pref - lung_c] + c)
            else:
                lista_codici.add(c)
    return sorted(lista_codici, key=int)

stringa = raw_input('lista codici:')

print stringa

print "\n".join(dividi_codici(stringa))
