from qgis.PyQt.QtCore import QSettings, QTranslator, QCoreApplication, pyqtSignal
from qgis.core import QgsProject
from qgis.core import QgsLayoutItemRegistry
from qgis.core import QgsUnitTypes
from qgis.core import QgsApplication
from qgis.core import QgsAuthMethodConfig

from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtWidgets import QAction, QDialog
from .imposta_parametri_connessione_dlg import ImpostaParametriConnessioneDlg

class ImpostaParametriConnessione(QDialog):
    parametriCambiati = pyqtSignal(int)
    def __init__(self, iface):
        # Save reference to the QGIS interface
        super(ImpostaParametriConnessione, self).__init__()
        
    def run(self):
        """Run method that performs all the real work"""
        
        settings = QSettings()
        dlg = ImpostaParametriConnessioneDlg()
        dlg.hostURL.setText(settings.value('cerca_gisbo/host', 'localhost'))
        dlg.hostPort.setText(settings.value('cerca_gisbo/port', '5432'))
        dlg.nomeDatabase.setText(settings.value('cerca_gisbo/database', 'postgis'))
        dlg.confAuth.setConfigId(settings.value('cerca_gisbo/auth_cfg_id', ''))
        self.dlg = dlg
        dlg.show()
        # Run the dialog event loop
        result = dlg.exec_()
        if result:
            settings.setValue('cerca_gisbo/host', dlg.hostURL.text())
            settings.setValue('cerca_gisbo/port', dlg.hostPort.text())
            settings.setValue('cerca_gisbo/database', dlg.nomeDatabase.text())
            settings.setValue('cerca_gisbo/auth_cfg_id', dlg.confAuth.configId())
            self.parametriCambiati.emit(2)
        else:
            self.parametriCambiati.emit(0)
            