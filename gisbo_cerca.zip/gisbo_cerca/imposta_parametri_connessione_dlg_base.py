# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'imposta_parametri_connessione_dlg_base.ui'
#
# Created by: PyQt5 UI code generator 5.12.3
#
# WARNING! All changes made in this file will be lost!


from PyQt5 import QtCore, QtGui, QtWidgets


class Ui_impostaParametriConnessioneDlgBase(object):
    def setupUi(self, impostaParametriConnessioneDlgBase):
        impostaParametriConnessioneDlgBase.setObjectName("impostaParametriConnessioneDlgBase")
        impostaParametriConnessioneDlgBase.resize(546, 240)
        impostaParametriConnessioneDlgBase.setMaximumSize(QtCore.QSize(546, 16777215))
        self.verticalLayout = QtWidgets.QVBoxLayout(impostaParametriConnessioneDlgBase)
        self.verticalLayout.setObjectName("verticalLayout")
        self.gridLayout = QtWidgets.QGridLayout()
        self.gridLayout.setObjectName("gridLayout")
        self.hostPort = QtWidgets.QLineEdit(impostaParametriConnessioneDlgBase)
        self.hostPort.setObjectName("hostPort")
        self.gridLayout.addWidget(self.hostPort, 1, 1, 1, 1)
        self.label_2 = QtWidgets.QLabel(impostaParametriConnessioneDlgBase)
        self.label_2.setObjectName("label_2")
        self.gridLayout.addWidget(self.label_2, 1, 0, 1, 1)
        self.label_3 = QtWidgets.QLabel(impostaParametriConnessioneDlgBase)
        self.label_3.setObjectName("label_3")
        self.gridLayout.addWidget(self.label_3, 2, 0, 1, 1)
        self.hostURL = QtWidgets.QLineEdit(impostaParametriConnessioneDlgBase)
        self.hostURL.setObjectName("hostURL")
        self.gridLayout.addWidget(self.hostURL, 0, 1, 1, 1)
        self.nomeDatabase = QtWidgets.QLineEdit(impostaParametriConnessioneDlgBase)
        self.nomeDatabase.setObjectName("nomeDatabase")
        self.gridLayout.addWidget(self.nomeDatabase, 2, 1, 1, 1)
        self.label = QtWidgets.QLabel(impostaParametriConnessioneDlgBase)
        self.label.setObjectName("label")
        self.gridLayout.addWidget(self.label, 0, 0, 1, 1)
        self.verticalLayout.addLayout(self.gridLayout)
        self.label_6 = QtWidgets.QLabel(impostaParametriConnessioneDlgBase)
        self.label_6.setObjectName("label_6")
        self.verticalLayout.addWidget(self.label_6)
        self.confAuth = QgsAuthConfigSelect(impostaParametriConnessioneDlgBase)
        sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Preferred, QtWidgets.QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.confAuth.sizePolicy().hasHeightForWidth())
        self.confAuth.setSizePolicy(sizePolicy)
        self.confAuth.setMinimumSize(QtCore.QSize(0, 40))
        self.confAuth.setObjectName("confAuth")
        self.verticalLayout.addWidget(self.confAuth)
        spacerItem = QtWidgets.QSpacerItem(20, 40, QtWidgets.QSizePolicy.Minimum, QtWidgets.QSizePolicy.Expanding)
        self.verticalLayout.addItem(spacerItem)
        self.buttonBox = QtWidgets.QDialogButtonBox(impostaParametriConnessioneDlgBase)
        self.buttonBox.setOrientation(QtCore.Qt.Horizontal)
        self.buttonBox.setStandardButtons(QtWidgets.QDialogButtonBox.Cancel|QtWidgets.QDialogButtonBox.Ok)
        self.buttonBox.setObjectName("buttonBox")
        self.verticalLayout.addWidget(self.buttonBox)

        self.retranslateUi(impostaParametriConnessioneDlgBase)
        self.buttonBox.accepted.connect(impostaParametriConnessioneDlgBase.accept)
        self.buttonBox.rejected.connect(impostaParametriConnessioneDlgBase.reject)
        QtCore.QMetaObject.connectSlotsByName(impostaParametriConnessioneDlgBase)

    def retranslateUi(self, impostaParametriConnessioneDlgBase):
        _translate = QtCore.QCoreApplication.translate
        impostaParametriConnessioneDlgBase.setWindowTitle(_translate("impostaParametriConnessioneDlgBase", "Dialog"))
        self.label_2.setText(_translate("impostaParametriConnessioneDlgBase", "port:"))
        self.label_3.setText(_translate("impostaParametriConnessioneDlgBase", "database:"))
        self.label.setText(_translate("impostaParametriConnessioneDlgBase", "host:"))
        self.label_6.setText(_translate("impostaParametriConnessioneDlgBase", "Autenticazione:"))
from qgsauthconfigselect import QgsAuthConfigSelect
