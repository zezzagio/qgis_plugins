# -*- coding: utf-8 -*-

import os

from qgis.PyQt import uic
from qgis.PyQt import QtWidgets
from .imposta_parametri_connessione_dlg_base import Ui_impostaParametriConnessioneDlgBase
# This loads your .ui file so that PyQt can populate your plugin with the elements from Qt Designer

class ImpostaParametriConnessioneDlg(QtWidgets.QDialog, Ui_impostaParametriConnessioneDlgBase):
    def __init__(self, parent=None):
        super(ImpostaParametriConnessioneDlg, self).__init__(parent)
        self.setupUi(self)
