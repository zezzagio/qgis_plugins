from PyQt4.QtCore import *
from PyQt4.QtGui import *

from ui import Ui_Dialog

from worker import Worker

class ui_Control(QDialog, Ui_Dialog):
    
    def __init__(self, parent):
        QDialog.__init__(self, parent)
        self.setupUi(self)

    def start_worker(self, copia_in_directory, campo_tema, aggiorna_dati):
        worker = Worker(copia_in_directory, campo_tema, aggiorna_dati)
        thread = QThread(self)
        worker.moveToThread(thread)
        worker.finished.connect(self.workerFinished)
        worker.error.connect(self.workerError)
        thread.started.connect(worker.run)
        worker.progress.connect(self.tell)
        thread.start()
        self.worker = worker            
        self.thread = thread
        
    def esporta_gis(self):
        reply = QMessageBox.question(self, 'Esporta GIS Bologna', 'Esportare GIS Bologna?', QMessageBox.Yes|QMessageBox.No, QMessageBox.No)
        
        if (reply== QMessageBox.Yes):
            try:
                esporta_dir = self.percorso.text()
                self.messaggi.clear()
                self.show()
                self.tell('<h1>Esportazione GIS Bologna:</h1><br>')
                self.repaint()
                if self.perComune.isChecked():
                    campo_tema = 'tema'
                else:
                    campo_tema = 'tema_christine'
                    
                if esporta_dir != '':
                    self.copia_in_directory = esporta_dir + '/'
                    self.buttonBox.button(QDialogButtonBox.Ok).setEnabled(False)
                    self.start_worker(self.copia_in_directory, campo_tema, self.aggSuperfici.isChecked())
                else:
                    self.tell('<h2>Impossibile esportare nel percorso selezionato</h2>')

            except RuntimeError, e:
                self.tell('<P>' + e)
            except Exception, e:
                self.tell(e, repr(e))

    def workerFinished(self, ret):
        # clean up the worker and thread
        reply = QMessageBox.question(self, 'Esporta GIS Bologna', 'Dovrebbe essere tutto finito', QMessageBox.Yes|QMessageBox.No, QMessageBox.No)
        self.worker.deleteLater()
        self.thread.quit()
        self.thread.wait()
        self.thread.deleteLater()
        self.buttonBox.button(QDialogButtonBox.Ok).setEnabled(True)
        # remove widget from message bar
        
    def workerError(self, e, exception_string):
        None
        #QgsMessageLog.logMessage('Worker thread raised an exception:\n'.format(exception_string), level=QgsMessageLog.CRITICAL)
        
    def tell(self, txt):
        # write to bottom of Note area at top of screen
        #self.messaggi.appendPlainText(txt)
        self.messaggi.appendHtml(txt)
        self.messaggi.repaint()
        
if __name__=="__main__":
    import sys,os
    app=QApplication(sys.argv)
    c=ui_Control(None)
    c.show()
    sys.exit(app.exec_())
