"""
"""
from esporta_gisbo import esporta_gisbo

def name():
  return "Esporta GIS Bologna"

def description():
  return "Esporta GIS Bologna"

def version():
  return "Version 0.1"

def qgisMinimumVersion():
  return "2.0"

def authorName():
  return "Giovanni Zezza"

def classFactory(iface):
  return esporta_gisbo(iface)
