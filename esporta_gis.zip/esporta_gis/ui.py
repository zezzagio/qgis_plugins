# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'ui.ui'
#
# Created: Tue Dec 02 17:57:46 2014
#      by: PyQt4 UI code generator 4.10.2
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_Dialog(object):
    def setupUi(self, Dialog):
        Dialog.setObjectName(_fromUtf8("Dialog"))
        Dialog.resize(460, 311)
        self.verticalLayout = QtGui.QVBoxLayout(Dialog)
        self.verticalLayout.setObjectName(_fromUtf8("verticalLayout"))
        self.label = QtGui.QLabel(Dialog)
        self.label.setObjectName(_fromUtf8("label"))
        self.verticalLayout.addWidget(self.label)
        self.horizontalLayout = QtGui.QHBoxLayout()
        self.horizontalLayout.setObjectName(_fromUtf8("horizontalLayout"))
        self.percorso = QtGui.QLineEdit(Dialog)
        self.percorso.setObjectName(_fromUtf8("percorso"))
        self.horizontalLayout.addWidget(self.percorso)
        self.selDir = QtGui.QPushButton(Dialog)
        self.selDir.setObjectName(_fromUtf8("selDir"))
        self.horizontalLayout.addWidget(self.selDir)
        self.verticalLayout.addLayout(self.horizontalLayout)
        self.groupBox = QtGui.QGroupBox(Dialog)
        self.groupBox.setObjectName(_fromUtf8("groupBox"))
        self.horizontalLayout_2 = QtGui.QHBoxLayout(self.groupBox)
        self.horizontalLayout_2.setObjectName(_fromUtf8("horizontalLayout_2"))
        self.perComune = QtGui.QRadioButton(self.groupBox)
        self.perComune.setChecked(True)
        self.perComune.setObjectName(_fromUtf8("perComune"))
        self.horizontalLayout_2.addWidget(self.perComune)
        self.perChristine = QtGui.QRadioButton(self.groupBox)
        self.perChristine.setObjectName(_fromUtf8("perChristine"))
        self.horizontalLayout_2.addWidget(self.perChristine)
        self.verticalLayout.addWidget(self.groupBox)
        self.aggSuperfici = QtGui.QCheckBox(Dialog)
        self.aggSuperfici.setChecked(False)
        self.aggSuperfici.setObjectName(_fromUtf8("aggSuperfici"))
        self.verticalLayout.addWidget(self.aggSuperfici)
        self.label_2 = QtGui.QLabel(Dialog)
        self.label_2.setObjectName(_fromUtf8("label_2"))
        self.verticalLayout.addWidget(self.label_2)
        self.messaggi = QtGui.QPlainTextEdit(Dialog)
        self.messaggi.setObjectName(_fromUtf8("messaggi"))
        self.verticalLayout.addWidget(self.messaggi)
        self.buttonBox = QtGui.QDialogButtonBox(Dialog)
        self.buttonBox.setOrientation(QtCore.Qt.Horizontal)
        self.buttonBox.setStandardButtons(QtGui.QDialogButtonBox.Cancel|QtGui.QDialogButtonBox.Ok)
        self.buttonBox.setCenterButtons(True)
        self.buttonBox.setObjectName(_fromUtf8("buttonBox"))
        self.verticalLayout.addWidget(self.buttonBox)

        self.retranslateUi(Dialog)
        QtCore.QObject.connect(self.buttonBox, QtCore.SIGNAL(_fromUtf8("rejected()")), Dialog.reject)
        QtCore.QMetaObject.connectSlotsByName(Dialog)

    def retranslateUi(self, Dialog):
        Dialog.setWindowTitle(_translate("Dialog", "Esportazione layer per Comune Bologna", None))
        self.label.setText(_translate("Dialog", "Directory in cui verranno esportati i file:", None))
        self.selDir.setText(_translate("Dialog", "scegli...", None))
        self.groupBox.setTitle(_translate("Dialog", "Destinazione", None))
        self.perComune.setText(_translate("Dialog", "Comune di Bologna", None))
        self.perChristine.setText(_translate("Dialog", "Christine", None))
        self.aggSuperfici.setText(_translate("Dialog", "Aggiornare i dati di superficie delle unità gestionali (può essere lungo)?", None))
        self.label_2.setText(_translate("Dialog", "Messaggi:", None))

