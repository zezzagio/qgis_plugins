#! /usr/bin/env python
# emacs-mode: -*- python-*-
# -*- coding: utf-8 -*-

import os 
import sys
#from osgeo import ogr
import stat, errno

sys.path.append('/usr/share/qgis/python')

from PyQt4.QtCore import * 
from PyQt4.QtGui import * 
from Queue import Queue

from ui_control import ui_Control

from worker import Worker

from math import * 

class WriteStream(object):
    def __init__(self,queue):
        self.queue = queue

    def write(self, text):
        self.queue.put(text)

class MyReceiver(QObject):
    mysignal = pyqtSignal(str)

    def __init__(self,queue,*args,**kwargs):
        QObject.__init__(self,*args,**kwargs)
        self.queue = queue

    @pyqtSlot()
    def run(self):
        while True:
            text = self.queue.get()
            if (text):
                self.mysignal.emit(text)

class esporta_gisbo:
    """
    """
    def __init__(self, thread, my_receiver):
        self.thread = thread
        self.receiver = my_receiver
        self.fPath = ''
        self.here = sys.path[0]
        self.default_christine = 'c:/documenti/bologna/censimento'
        self.copia_in_directory = self.default_christine

    def __del__(self):
        self.receiver.deleteLater()
        self.thread.quit()
        self.thread.deleteLater()
        
    def initGui(self):
        self.pluginGui = ui_Control(None)
        self.messaggi = self.pluginGui.messaggi
        self.pluginGui.percorso.setText(self.copia_in_directory)
        buttonBox = self.pluginGui.buttonBox
        QObject.connect(buttonBox.button(QDialogButtonBox.Ok),SIGNAL("clicked()"),self.pluginGui.esporta_gis)
        QObject.connect(self.pluginGui.selDir,SIGNAL("clicked()"),self.scegliDir)
        QObject.connect(self.pluginGui.perChristine,SIGNAL("toggled(bool)"),self.set_default_christine)

    def set_default_christine(self, christine):
        if christine:
            self.pluginGui.percorso.setText(self.default_christine)
        
    def scegliDir(self):
        esporta_dir = QFileDialog.getExistingDirectory(QWidget(), "Seleziona directory di esportazione",
            self.copia_in_directory,
            QFileDialog.ShowDirsOnly | QFileDialog.DontResolveSymlinks)
        if esporta_dir:
            self.pluginGui.percorso.setText(esporta_dir)

    def unload(self):
        self.iface.removePluginMenu('&Esporta GIS', self.action)
        self.saveConf()

    def run(self):
        self.pluginGui.show()
        self.pluginGui.repaint()

    def tell(self, txt):
        # write to bottom of Note area at top of screen
        #self.messaggi.appendPlainText(txt)
        self.pluginGui.tell(txt)

    def saveConf(self):
        settings = QSettings()
        settings.setValue('/Plugin-esporta_gisbo/inp_exp_dir', self.fPath)

if __name__=="__main__":
    queue = Queue()
    sys.stdout = WriteStream(queue)
    
    my_receiver = MyReceiver(queue)
    
    app=QApplication(sys.argv)
    
    thread = QThread()

    c=esporta_gisbo(thread, my_receiver)
    c.initGui()
    
    c.run()

    my_receiver.mysignal.connect(c.pluginGui.tell)
    my_receiver.moveToThread(thread)
    thread.started.connect(my_receiver.run)
    thread.start()

    sys.exit(app.exec_())
