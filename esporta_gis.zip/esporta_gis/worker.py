﻿#! /usr/bin/env python
# emacs-mode: -*- python-*-
# -*- coding: utf-8 -*-

import os 
import sys
from osgeo import ogr
import stat, errno

from PyQt4.QtCore import * 
from PyQt4.QtGui import * 

import time
#import resources 

class Worker(QObject):
    
    finished = pyqtSignal(bool)
    error = pyqtSignal(Exception, basestring)
    progress = pyqtSignal(basestring)
    
    def __init__(self, copia_in_directory, campo_tema, aggiorna_dati):
        QObject.__init__(self)
        if (not os.path.isdir(copia_in_directory)):
            raise TypeError(u"La directory di destinazione non è valida")
        self.copia_in_directory = copia_in_directory
        self.conn_string = "host='verde06' dbname='postgis' port='5432' user='bologna' password='bologna'"
        self.campo_tema = campo_tema
        self.aggiorna_dati = aggiorna_dati

        self.killed = False
        
    def aggiorna_siepi(self, connection):
        print 'Aggiorno campi superfici siepi'
        
        cursore = connection.cursor()
        sql_siepi = "update bologna.siepi set lunghezza = 0, sup_pot = 0"
        cursore.execute(sql_siepi)
        cursore.close()

    def aggiorna_pavimentazioni(self, connection):
        print 'Aggiorno campi superfici pavimentazioni'
        cursore = connection.cursor()
        sql_pavim = "update bologna.pavim set area_pav = round(st_area(the_geom)::numeric, 2)"
        cursore.execute(sql_pavim)
        cursore.close()
        
    def aggiorna_popolamenti(self, connection):
        print 'Aggiorno campi superfici popolamenti arborei'
        cursore = connection.cursor()
        sql_pop_arb = "update bologna.pop_arb set pop_area = round(st_area(the_geom)::numeric, 2)"
        cursore.execute(sql_pop_arb)
        cursore.close()
        

    def aggiorna_sup_canone(self, connection):
        print 'Aggiorno campo superficie a canone'
        
        cursore = connection.cursor()
        sql_canon = """with a (cod_pre, sup) as
        (select cod_pre, sum(st_area(the_geom))
        from bologna.un_gest
        group by cod_pre)
        update bologna.un_gest as u
        set area_canon = round(a.sup::numeric, 3)
        from a
        where a.cod_pre = u.cod_pre"""

        cursore.execute(sql_canon)
        cursore.close()
        
    def aggiorna_ripartizioni_sup(self, connection):
        print 'Aggiorno campi ripartizioni superfici'
        
        sql_ripsup = """select 'Aggiornati ' || count(*)::text || ' poligoni' as report
        from bologna.un_gest, bologna.ripartizione_superfici_ug(cod_ug) as r"""

        cursore = connection.cursor()
        
        cursore.execute(sql_ripsup)

        for riga in cursore:
            report = riga[0]
            print '<b>' + report + '</b>'
            
        cursore.close()

    def aggiorna_dati_superfici(self, connection):
        import psycopg2
        try:
            connection = psycopg2.connect(self.conn_string)
            
            self.aggiorna_siepi(connection)
            self.aggiorna_pavimentazioni(connection)
            self.aggiorna_popolamenti(connection)
            self.aggiorna_sup_canone(connection)
            self.aggiorna_ripartizioni_sup(connection)
            connection.commit()
            connection.close()
        except Exception, e:
            print repr(e)

    def run(self):
        try:
            campo_tema = self.campo_tema
            
            tipi_geom = {'LINESTRING' : ogr.wkbLineString,
                'MULTILINESTRING' : ogr.wkbMultiLineString,
                'POLYGON' : ogr.wkbPolygon,
                'MULTIPOLYGON' : ogr.wkbMultiPolygon,
                'POINT' : ogr.wkbPoint,
                'MULTIPOINT' : ogr.wkbMultiPoint}

            ogr.UseExceptions()
            
            driver = ogr.GetDriverByName('PostgreSQL')

            inDataSource = driver.Open('PG: ' + self.conn_string)

            if (self.aggiorna_dati):
                self.aggiorna_dati_superfici(inDataSource)
            
            sql_command = """SELECT *
            FROM bologna.lista_temi
            WHERE processa
            ORDER BY {0}""".format(campo_tema)
            
            temi_da_esportare = inDataSource.ExecuteSQL(sql_command)

            self.mkdir_p(str(self.copia_in_directory))

            for tema in temi_da_esportare:
                tabella_postgis = tema.GetField('tabella_postgis')
                outLayerName = tema.GetField(campo_tema)
                outGeomType = tipi_geom[tema.GetField('tipo')]
                filtro = tema.GetField('filtro')
                print 'Esporto <b>%s</b>' % outLayerName
                self.esporta_tabella(tabella_postgis, inDataSource, filtro, outLayerName, outGeomType)

        except RuntimeError, e:
            print('<P>' + repr(e))
        except Exception, e:
            print('<P>' + repr(e))

        try:
            inDataSource.Destroy()
        except:
            print "<P><i>Non c'e' niente da distruggere</i>"

        print '<P><b>Esportazione terminata</b>'
        self.finished.emit(True)
        
    def mkdir_p(self, path):
        try:
            os.makedirs(path)
        except OSError as exc:  # Python >2.5
            if exc.errno == errno.EEXIST and os.path.isdir(path):
                pass
            else:
                raise TypeError(u"La directory di destinazione non è valida")

    def ShapeFileName(self, outLayerName):
        #here = sys.path[0]
        #nome_file = here + '/shape/' + outLayerName + '.shp'
        nome_file = str(self.copia_in_directory) + outLayerName + '.shp'
        return nome_file

    def crea_out_datasource(self, outLayerName):

        nome_file_shape_out = self.ShapeFileName(outLayerName)

        outDriver = ogr.GetDriverByName("ESRI Shapefile")

        # Remove output shapefile if it already exists
        if os.path.exists(nome_file_shape_out):
            outDriver.DeleteDataSource(nome_file_shape_out)

        # Create the output shapefile
        outDataSource = outDriver.CreateDataSource(nome_file_shape_out)

        return outDataSource

    def aggiungi_campi_layer(self, tabella_attributi, outLayer):

        ls_campi_postgis = []

        for record in tabella_attributi:
            nome_campo_dbf = record.GetField('campo_dbf')
            tipo_campo_dbf = record.GetField('tipo')
            lunghezza = record.GetField('lunghezza')
            precisione = record.GetField('precisione')
            nome_campo_postgis = record.GetField('campo_postgis')

            ls_campi_postgis.append(nome_campo_postgis)

            if tipo_campo_dbf == 'N':
                if precisione == 0:
                    tipo_campo = ogr.OFTInteger
                else:
                    tipo_campo = ogr.OFTReal
            elif tipo_campo_dbf == 'C':
                tipo_campo = ogr.OFTString
            elif tipo_campo_dbf == 'F':
                tipo_campo = ogr.OFTReal
            elif tipo_campo_dbf == 'D':
                tipo_campo = ogr.OFTDate
            else:
                tipo_campo = ogr.OFTString

            def_campo = ogr.FieldDefn(nome_campo_dbf, tipo_campo)
            def_campo.SetWidth(lunghezza)
            def_campo.SetPrecision(precisione)
            outLayer.CreateField(def_campo)

        return ls_campi_postgis

    def scrivi_tema(self, inLayer, outLayer):

        outLayerDefn = outLayer.GetLayerDefn()
        num_fields = outLayerDefn.GetFieldCount()

        for inFeature in inLayer:
            # Create output Feature
            outFeature = ogr.Feature(outLayerDefn)
            # Add field values from input Layer
            for i in range(0, num_fields):
                valore = inFeature.GetField(i)
                if valore != None:
                    outFeature.SetField(i, valore)
            geom = inFeature.GetGeometryRef()
            outFeature.SetGeometry(geom)
            # Add new feature to output Layer
            outLayer.CreateFeature(outFeature)

    def crea_cursore_attributi(self, inDataSource, outLayerName):
        sql_command = """SELECT * FROM bologna.attributi_temi
            WHERE tema = '{0}'
            ORDER by ordine
            """.format(outLayerName)
        tabella_attributi = inDataSource.ExecuteSQL(sql_command)
        return tabella_attributi

    def get_geom_col(self, inDataSource, nome_tabella):
        sql_command = """SELECT f_geometry_column AS geom
        FROM geometry_columns
        WHERE f_table_schema || '.' || f_table_name = '{0}';
        """.format(nome_tabella)
        cursore = inDataSource.ExecuteSQL(sql_command)
        record = cursore.GetFeature(0)
        return record.GetField('geom')

    def apri_inLayer(self, inDataSource, ls_campi_postgis, tabella_postgis, filtro):
        sql_command = 'SELECT ' + ",\n".join(ls_campi_postgis)
        sql_command += "\nFROM " + tabella_postgis
        if (filtro):
            sql_command += "\nWHERE " + filtro
        sql_command += "\nORDER BY gid"
        inLayer = inDataSource.ExecuteSQL(sql_command)
        return inLayer

    def esporta_tabella(self, tabella_postgis, inDataSource, filtro, outLayerName, outGeomType):

        outDataSource = self.crea_out_datasource(str(outLayerName))


        outLayer = outDataSource.CreateLayer(outLayerName, geom_type = outGeomType)

        tabella_attributi = self.crea_cursore_attributi(inDataSource, outLayerName)


        ls_campi_postgis = self.aggiungi_campi_layer(tabella_attributi, outLayer)

        colonna_geom = self.get_geom_col(inDataSource, tabella_postgis)
        ls_campi_postgis.append(colonna_geom)

        inLayer = self.apri_inLayer(inDataSource, ls_campi_postgis, tabella_postgis, filtro)

        self.scrivi_tema(inLayer, outLayer)

        outDataSource.Destroy()
    def kill(self):
        self.killed = True
