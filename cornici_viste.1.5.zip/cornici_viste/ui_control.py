from PyQt5.QtCore import *
from PyQt5.QtGui import *
from PyQt5.QtWidgets import *

from .Ui_ui import Ui_ui


class ui_Control(QDialog, Ui_ui):
    def __init__(self, parent):
        QDialog.__init__(self, parent)
        self.setupUi(self)
        layout = self.groupBox_3
        self.setFocusPolicy(Qt.ClickFocus)
        self.installEventFilter(self)
        
    def eventFilter(self,object,event):
        if event.type() == QEvent.WindowActivate:
            self.refreshStates()
        return False
        
    def refreshStates(self):
        layer = self.comboBox_layers.currentLayer()
        self.toggleEdit.setChecked(layer.isEditable())
    
#        nuovoV = QLineEdit(layout)
if __name__=="__main__":
    import sys,os
    app=QApplication(sys.argv)
    c=ui_Control(None)
    c.show()
    sys.exit(app.exec_())
