﻿# -*- coding: utf-8 -*-

import os

from qgis.PyQt import uic
from qgis.PyQt import QtWidgets
from .leggi_layout_dialog_base import Ui_LeggiLayoutDialogBase
# This loads your .ui file so that PyQt can populate your plugin with the elements from Qt Designer

class LeggiLayoutDialog(QtWidgets.QDialog, Ui_LeggiLayoutDialogBase):
    def __init__(self, parent=None):
        super(LeggiLayoutDialog, self).__init__(parent)
        self.setupUi(self)
