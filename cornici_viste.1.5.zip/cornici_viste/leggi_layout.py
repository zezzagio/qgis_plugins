from qgis.PyQt.QtCore import QSettings, QTranslator, QCoreApplication, pyqtSignal
from qgis.core import QgsProject
from qgis.core import QgsLayoutItemRegistry
from qgis.core import QgsUnitTypes
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtWidgets import QAction, QDialog

# Initialize Qt resources from file resources.py
from .resources import *
# Import the code for the dialog
from .leggi_layout_dialog import LeggiLayoutDialog
import os.path


class LeggiLayout(QDialog):
    applicaDimensioni = pyqtSignal(list)
    def __init__(self, iface):
        # Save reference to the QGIS interface
        super(LeggiLayout, self).__init__()
        self.iface = iface
        # initialize plugin directory
        self.plugin_dir = os.path.dirname(__file__)
        # initialize locale
        locale = QSettings().value('locale/userLocale')[0:2]
        locale_path = os.path.join(
            self.plugin_dir,
            'i18n',
            'LeggiLayout_{}.qm'.format(locale))

        if os.path.exists(locale_path):
            self.translator = QTranslator()
            self.translator.load(locale_path)
            QCoreApplication.installTranslator(self.translator)

        # Declare instance attributes
        self.actions = []
        self.menu = self.tr(u'&Leggi Layout')

        # Check if plugin was started the first time in current QGIS session
        # Must be set in initGui() to survive plugin reloads
        self.first_start = None

    # noinspection PyMethodMayBeStatic
    def tr(self, message):
        """Get the translation for a string using Qt translation API.

        We implement this ourselves since we do not inherit QObject.

        :param message: String for translation.
        :type message: str, QString

        :returns: Translated version of message.
        :rtype: QString
        """
        # noinspection PyTypeChecker,PyArgumentList,PyCallByClass
        return QCoreApplication.translate('LeggiLayout', message)


    def riempi_lista_layout(self):
        progetto = QgsProject.instance()
        layout_manager = progetto.layoutManager()
        ls_layout = layout_manager.printLayouts()
        self.dlg.listaLayout.clear()
        for i in range(0, len(ls_layout)):
            l = ls_layout[i]
            mappe = self.trova_mappe(l)
            self.dlg.listaLayout.addItem(l.name(), [i, mappe])
        self.leggi_dimensioni()

    def trova_mappe(self, layout):
        tipo_mappa = QgsLayoutItemRegistry.LayoutMap
        ls_map = []
        for i in layout.items():
            if i.type() == tipo_mappa:
                ls_map.append(i.uuid())
        return ls_map
        
    def leggi_dimensioni(self):
        self.dlg.listaDimensioni.clear()
        progetto = QgsProject.instance()
        layout_manager = progetto.layoutManager()
        ls_layout = layout_manager.printLayouts()
        #i = listaMappe.currentIndex
        d = self.dlg.listaLayout.currentData()
        if d:
            indice_layout = d[0]
            l = ls_layout[indice_layout]
            for uuid in d[1]:
                i = l.itemByUuid(uuid)
                s = i.sizeWithUnits()
                unita_layout = QgsUnitTypes.toAbbreviatedString(s.units())
                unita = QgsUnitTypes.decodeDistanceUnit(unita_layout)
                if unita[1]:
                    fattore = QgsUnitTypes.fromUnitToUnitFactor(unita[0], QgsUnitTypes.DistanceMillimeters)
                    width = fattore * s.width()
                    height = fattore * s.height()
                    label = '{}: {:.0f} X {:.0f}'.format(i.displayName(), width, height)
                    self.dlg.listaDimensioni.addItem(label, [width, height])
                else:
                    self.dlg.listaDimensioni.addItem('{}: {}'.format(i.displayName(), ['dimensioni non riconosciute'], []))

    def applica_dimensioni(self, xy):
        dimensioni = self.dlg.listaDimensioni.currentData()
        if dimensioni:
            self.applicaDimensioni.emit(dimensioni)
        
    def run(self):
        """Run method that performs all the real work"""

        self.dlg = LeggiLayoutDialog()
        self.riempi_lista_layout()
        self.dlg.listaLayout.currentIndexChanged.connect(self.leggi_dimensioni)
        self.dlg.assegna_misure.clicked.connect(self.applica_dimensioni)
        # show the dialog
        self.dlg.show()
        # Run the dialog event loop
        result = self.dlg.exec_()
        # See if OK was pressed
        if result:
            self.dlg.assegna_misure.clicked.disconnect(self.applica_dimensioni)
            self.dlg.listaLayout.currentIndexChanged.disconnect(self.leggi_dimensioni)
                                