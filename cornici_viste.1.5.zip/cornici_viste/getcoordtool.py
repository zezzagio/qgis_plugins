#---------------------------------------------------------------------
# 
# licensed under the terms of GNU GPL 2
# 
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
# 
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
# 
# You should have received a copy of the GNU General Public License along
# with this program; if not, write to the Free Software Foundation, Inc.,
# 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
# 
#---------------------------------------------------------------------

from PyQt5.QtCore import *
from PyQt5.QtGui import *
from qgis.core import *
from qgis.gui import *
from math import *

# Raster File Info Tool class
class GetCoordTool(QgsMapTool):
  finished = pyqtSignal(list)
  def __init__(self, canvas, dimensioni):
    QgsMapTool.__init__(self,canvas)
    self.canvas=canvas
    self.dimensioni=dimensioni

    self.rb = QgsRubberBand(self.canvas,  QgsWkbTypes.PolygonGeometry)
    
    self.rb1 = QgsRubberBand(self.canvas,  QgsWkbTypes.PolygonGeometry)
    color1 = QColor(0,255,0, 127)
    self.rb1.setColor(color1) 
    self.rb1.setWidth(1)      
    self.rb1.reset(QgsWkbTypes.PolygonGeometry)
    
    self.cursor = QCursor(QPixmap(["16 16 3 1",
                                  "      c None",
                                  ".     c #FF0000",
                                  "+     c #FFFFFF",
                                  "                ",
                                  "       +.+      ",
                                  "      ++.++     ",
                                  "     +.....+    ",
                                  "    +.     .+   ",
                                  "   +.   .   .+  ",
                                  "  +.    .    .+ ",
                                  " ++.    .    .++",
                                  " ... ...+... ...",
                                  " ++.    .    .++",
                                  "  +.    .    .+ ",
                                  "   +.   .   .+  ",
                                  "   ++.     .+   ",
                                  "    ++.....+    ",
                                  "      ++.++     ",
                                  "       +.+      "]))
  
  def canvasPressEvent(self,event):
    pixels=event.pos()
    
    transform = self.canvas.getCoordinateTransform()
    xy = transform.toMapCoordinates(pixels) #captures the clicked coordinate and transform
    color = QColor(255,0,0, 127)
    self.rb.setColor(color) 
    self.rb.setWidth(1)      
    self.rb.reset(QgsWkbTypes.PolygonGeometry)
    
    color1 = QColor(0,255,0, 127)
    self.rb1.setColor(color1) 
    self.rb1.setWidth(1)      
    self.rb1.reset(QgsWkbTypes.PolygonGeometry)
    
    (scala, xOffset, yOffset, orientamento) = self.dimensioni()

    (pt1, pt2, pt3, pt4) = self.rot_rect(xy, xOffset, yOffset)

    self.finished.emit([pt1, pt2, pt3, pt4, pt1])     #return rectangle in a signal

      
  def canvasMoveEvent(self,event):
    pixels=event.pos()
    transform = self.canvas.getCoordinateTransform()
    pt = transform.toMapCoordinates(pixels) #captures the clicked coordinate and transform

    (scala, xOffset, yOffset, orientamento) = self.dimensioni()

    (pt1, pt2, pt3, pt4) = self.rot_rect(pt, xOffset, yOffset)
    
    self.rb1.reset(QgsWkbTypes.PolygonGeometry)
    self.rb1.addPoint(pt1)
    self.rb1.addPoint(pt2)
    self.rb1.addPoint(pt3)
    self.rb1.addPoint(pt4)
    #self.rb1.addPoint(pt1)
    #self.emit(SIGNAL("finished(PyQt_PyObject)"),pt)     #return QgsPoint in a signal
    #msgbar = QgsMessageBar()
    #msgbar.pushMessage(','.join((str(x1), str(y1), str(x2), str(y2))))
    pass
  
  def canvasReleaseEvent(self,event):
    pass
            
  def activate(self):
    QgsMapTool.activate(self)
    self.canvas.setCursor(self.cursor)
  
  def deactivate(self):
    #QgsMapTool.deactivate(self)
    self.rb1.reset(QgsWkbTypes.PolygonGeometry)
    pass
    
  def rot_rect(self, pt, xOffset, yOffset):
      
    def ruota(d):
        a = d  * (pi / 180)
        rs = sin(a)
        rc = cos(a)
        def r(x, y):
            return (x * rc - y * rs, x * rs + y * rc) 
        return r
        
    r = ruota(self.canvas.rotation())
    
    x = pt.x()
    y = pt.y()
    
    (dx3, dy3) = r( xOffset,  yOffset)
    (dx4, dy4) = r( xOffset, -yOffset)
    (dx1, dy1) = (-dx3, -dy3)
    (dx2, dy2) = (-dx4, -dy4)
    
    pt1 = QgsPointXY(x + dx1, y + dy1)
    pt2 = QgsPointXY(x + dx2, y + dy2)
    pt3 = QgsPointXY(x + dx3, y + dy3)
    pt4 = QgsPointXY(x + dx4, y + dy4)
    
    return (pt1, pt2, pt3, pt4)
    
  def isZoomTool(self):
    return False

