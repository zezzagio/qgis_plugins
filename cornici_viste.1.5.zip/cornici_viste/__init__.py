"""
Copyright (C) 2008-2009 Mauricio Carvalho Mathias de Paulo
/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
"""
from .cornici_viste import cornici_viste

def name():
  return "Cornici viste"

def description():
  return "Crea cornici per le stampe"

def version():
  return "Version 1.5"

def qgisMinimumVersion():
  return "3.0"

def authorName():
  return "Giovanni Zezza"

def classFactory(iface):
  return cornici_viste(iface)
