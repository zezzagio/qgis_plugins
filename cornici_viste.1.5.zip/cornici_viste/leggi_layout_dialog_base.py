# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'leggi_layout_dialog_base.ui'
#
# Created by: PyQt5 UI code generator 5.12.3
#
# WARNING! All changes made in this file will be lost!


from PyQt5 import QtCore, QtGui, QtWidgets


class Ui_LeggiLayoutDialogBase(object):
    def setupUi(self, LeggiLayoutDialogBase):
        LeggiLayoutDialogBase.setObjectName("LeggiLayoutDialogBase")
        LeggiLayoutDialogBase.resize(365, 187)
        self.verticalLayout = QtWidgets.QVBoxLayout(LeggiLayoutDialogBase)
        self.verticalLayout.setObjectName("verticalLayout")
        self.horizontalLayout_2 = QtWidgets.QHBoxLayout()
        self.horizontalLayout_2.setObjectName("horizontalLayout_2")
        self.label = QtWidgets.QLabel(LeggiLayoutDialogBase)
        sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Fixed, QtWidgets.QSizePolicy.Preferred)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.label.sizePolicy().hasHeightForWidth())
        self.label.setSizePolicy(sizePolicy)
        self.label.setObjectName("label")
        self.horizontalLayout_2.addWidget(self.label)
        self.listaLayout = QtWidgets.QComboBox(LeggiLayoutDialogBase)
        self.listaLayout.setObjectName("listaLayout")
        self.horizontalLayout_2.addWidget(self.listaLayout)
        self.verticalLayout.addLayout(self.horizontalLayout_2)
        self.horizontalLayout_3 = QtWidgets.QHBoxLayout()
        self.horizontalLayout_3.setObjectName("horizontalLayout_3")
        self.label_2 = QtWidgets.QLabel(LeggiLayoutDialogBase)
        sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Fixed, QtWidgets.QSizePolicy.Preferred)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.label_2.sizePolicy().hasHeightForWidth())
        self.label_2.setSizePolicy(sizePolicy)
        self.label_2.setObjectName("label_2")
        self.horizontalLayout_3.addWidget(self.label_2)
        self.listaDimensioni = QtWidgets.QComboBox(LeggiLayoutDialogBase)
        self.listaDimensioni.setObjectName("listaDimensioni")
        self.horizontalLayout_3.addWidget(self.listaDimensioni)
        self.verticalLayout.addLayout(self.horizontalLayout_3)
        self.assegna_misure = QtWidgets.QPushButton(LeggiLayoutDialogBase)
        self.assegna_misure.setObjectName("assegna_misure")
        self.verticalLayout.addWidget(self.assegna_misure)
        self.button_box = QtWidgets.QDialogButtonBox(LeggiLayoutDialogBase)
        self.button_box.setOrientation(QtCore.Qt.Horizontal)
        self.button_box.setStandardButtons(QtWidgets.QDialogButtonBox.Cancel|QtWidgets.QDialogButtonBox.Ok)
        self.button_box.setObjectName("button_box")
        self.verticalLayout.addWidget(self.button_box)

        self.retranslateUi(LeggiLayoutDialogBase)
        self.button_box.accepted.connect(LeggiLayoutDialogBase.accept)
        self.button_box.rejected.connect(LeggiLayoutDialogBase.reject)
        QtCore.QMetaObject.connectSlotsByName(LeggiLayoutDialogBase)

    def retranslateUi(self, LeggiLayoutDialogBase):
        _translate = QtCore.QCoreApplication.translate
        LeggiLayoutDialogBase.setWindowTitle(_translate("LeggiLayoutDialogBase", "Leggi Layout"))
        self.label.setText(_translate("LeggiLayoutDialogBase", "Modelli di stampa"))
        self.label_2.setText(_translate("LeggiLayoutDialogBase", "Mappe del modello"))
        self.assegna_misure.setText(_translate("LeggiLayoutDialogBase", "Assegna misure mappa"))
