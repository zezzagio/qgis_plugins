#---------------------------------------------------------------------
#
# licensed under the terms of GNU GPL 2
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along
# with this program; if not, write to the Free Software Foundation, Inc.,
# 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
#
#---------------------------------------------------------------------

import os,sys
sys.path.append("/usr/share/qgis/python")
from PyQt5.QtCore import *
from PyQt5.QtGui import *
from PyQt5.QtWidgets import * 
from qgis.core import *

from .ui_control import ui_Control
from .resources import *
from math import *
from .getcoordtool import *
from .leggi_layout import LeggiLayout

class cornici_viste (object):
    """
    """

    # just a test to see if mods are taking

    def __init__(self, iface):
        self.iface = iface
        self.canvas = iface.mapCanvas()
        self.punta = False
        self.fPath = ''  # set default working directory, updated from config file & by Import/Export

    def initGui(self):
        # create action that will start plugin configuration
        self.action = QAction(QIcon(":/cornici_viste.png"), "Cornici viste", self.iface.mainWindow())
        self.action.setWhatsThis("Cornici viste")
        self.iface.addToolBarIcon(self.action)

        self.action.triggered.connect(self.run)

        # add toolbar button and menu item
        self.iface.addPluginToMenu("&Cornici viste", self.action)
        self.pluginGui = ui_Control(self.iface.mainWindow())        
        self.tool = GetCoordTool(self.canvas, self.dimensioni)
        self.leggi_layout = LeggiLayout(self.iface.mainWindow())

    def unload(self):
        # remove the plugin menu item and icon
        self.iface.removePluginMenu("&Cornici viste",self.action)
        self.iface.removeToolBarIcon(self.action)
        self.saveConf()
        
    def leggi_dimensioni(self):
        self.leggi_layout.applicaDimensioni.connect(self.applica_dimensioni)
        self.leggi_layout.run()
        self.leggi_layout.applicaDimensioni.disconnect(self.applica_dimensioni)
        
    def applica_dimensioni(self, xy):
        self.pluginGui.larghezza.setText(str(xy[0]))
        self.pluginGui.altezza.setText(str(xy[1]))

    def run(self):
        # create and show a configuration dialog or something similar
        flags = Qt.WindowTitleHint | Qt.WindowSystemMenuHint | Qt.WindowMaximizeButtonHint  # QgisGui.ModalDialogFlags
        self.pluginGui = ui_Control(self.iface.mainWindow())

        #misc init

        #INSERT EVERY SIGNAL CONECTION HERE!
        layers = self.pluginGui.comboBox_layers

        layers.setFilters(QgsMapLayerProxyModel.PolygonLayer | QgsMapLayerProxyModel.LineLayer)
        layers.layerChanged.connect(self.cambiolayer)
        self.pluginGui.toggleEdit.clicked.connect(self.toggleLayerEditable)
        self.pluginGui.pushButton_punta.clicked.connect(self.startgetpoint)
        self.pluginGui.leggiLayout.clicked.connect(self.leggi_dimensioni)
        self.pluginGui.show()

    def addgeometry(self, polygon):
        lyrNdx = self.pluginGui.comboBox_layers.findText(self.pluginGui.comboBox_layers.currentText())
        vectorlayer = self.pluginGui.comboBox_layers.currentLayer()

        #check if the layer is editable
        if (not vectorlayer.isEditable()):
            msg = QMessageBox(self.pluginGui)
            msg.setText("Layer not in edit mode.")
            msg.setWindowTitle("Layer")
            msg.open()
            return 0

        geometrytype = vectorlayer.geometryType()

        campoarea = self.pluginGui.campoArea.currentText()
        area = self.pluginGui.area.text()

        campoquartiere = self.pluginGui.campoQuartiere.currentText()
        quartiere = self.pluginGui.quartiere.text()
        
        campocategoria = self.pluginGui.campoCategoria.currentText()
        categoria = self.pluginGui.categoria.text()

        camposcala = self.pluginGui.campoScala.currentText()
        campoorient = self.pluginGui.campoOrient.currentText()
        
        campoangolo = self.pluginGui.campoAngolo.currentText()

        if (geometrytype == QgsWkbTypes.LineGeometry):
            
            geom = QgsGeometry.fromPolylineXY(polygon)
            
        elif geometrytype == QgsWkbTypes.PolygonGeometry:
            
            geom = QgsGeometry.fromPolygonXY([polygon])

        campi = vectorlayer.fields()
            
        feature=QgsFeature(campi)
            
        feature.setGeometry(geom)
            
        if (area != ''):
            feature[campoarea] = area
        if (quartiere != ''):
            feature[campoquartiere] = quartiere
        if (categoria != ''):
            feature[campocategoria] =  categoria
            
        (scala, xOffset, yOffset, orientamento) = self.dimensioni()
        
        feature[camposcala] = scala
        feature[campoorient] =  orientamento
        feature[campoangolo] = self.iface.mapCanvas().rotation()  
            
        vectorlayer.addFeature(feature)
        self.iface.mapCanvas().refresh()

    def dimensioni(self):
        txtScala = self.pluginGui.valScala.text()
        
        try:
            scala = abs(int(txtScala))
            if scala == 0:
                scala = 1000
        except:
            scala = 1000
            
        self.pluginGui.valScala.setText(str(scala))
        
        txtLarghezza = self.pluginGui.larghezza.text()
        
        try:
            xOffset = abs(float(txtLarghezza))
            if (xOffset == 0):
                xOffset = 345
        except:
            xOffset = 345
            
        self.pluginGui.larghezza.setText(str(xOffset))
            
        xOffset = (xOffset * scala / 1000)/2
        txtAltezza = self.pluginGui.altezza.text()
        
        try:
            yOffset = abs(float(txtAltezza))
            if (yOffset == 0):
                yOffset = 260
        except:
            yOffset = 260

        self.pluginGui.altezza.setText(str(yOffset))
        
        yOffset = (yOffset * scala / 1000)/2
        
        if (self.pluginGui.radioButton_orizzontale.isChecked()):
            orientamento = 'L'
        else:
            orientamento = 'P'
            (xOffset, yOffset) = (yOffset, xOffset)
        return (scala, xOffset, yOffset, orientamento)

    def moveup(self):
        pass

    def movedown(self):
        pass

    def startgetpoint(self):
        #point capture tool
        if (self.punta):
            self.canvas.setMapTool(self.saveTool)
            self.punta = False
            self.tool.finished.disconnect(self.getpoint)
            return
        self.punta = True
        self.tool.finished.connect(self.getpoint)
        self.saveTool = self.canvas.mapTool()
        self.canvas.setMapTool(self.tool)

    def getpoint(self, rect):
        #self.pluginGui.lineEdit_vertexX0.setText(str(pt.x()))
        #self.pluginGui.lineEdit_vertexY0.setText(str(pt.y()))
        self.addgeometry(rect)#aggiunto
        self.canvas.setMapTool(self.saveTool)
        self.punta = False
        self.tool.finished.disconnect(self.getpoint)

    def cambiolayer(self, lyrNdx):
        layer = self.pluginGui.comboBox_layers.currentLayer()
        self.pluginGui.campoArea.setLayer(layer)
        self.pluginGui.campoQuartiere.setLayer(layer)
        self.pluginGui.campoCategoria.setLayer(layer)
        self.pluginGui.campoScala.setLayer(layer)
        self.pluginGui.campoOrient.setLayer(layer)
        self.pluginGui.campoAngolo.setLayer(layer)
        self.pluginGui.toggleEdit.setChecked(layer.isEditable())
        for (campo) in (layer.fields()):
            nome = campo.name()
            uNome = nome.upper()

            if (uNome == 'AREA'):
                fldNdx = self.pluginGui.campoArea.findText(nome)
                self.pluginGui.campoArea.setCurrentIndex(fldNdx)

            if (uNome == 'QUARTIERE'):
                fldNdx = self.pluginGui.campoQuartiere.findText(nome)
                self.pluginGui.campoQuartiere.setCurrentIndex(fldNdx)
                
            if (uNome == 'CATEGORIA'):
                fldNdx = self.pluginGui.campoCategoria.findText(nome)
                self.pluginGui.campoCategoria.setCurrentIndex(fldNdx)
        
            if (uNome == 'SCALA'):
                fldNdx = self.pluginGui.campoScala.findText(nome)
                self.pluginGui.campoScala.setCurrentIndex(fldNdx)

            if (uNome == 'ORIENT'):
                fldNdx = self.pluginGui.campoOrient.findText(nome)
                self.pluginGui.campoOrient.setCurrentIndex(fldNdx)
                
            if (uNome == 'ANGOLO'):
                fldNdx = self.pluginGui.campoAngolo.findText(nome)
                self.pluginGui.campoAngolo.setCurrentIndex(fldNdx)

    def toggleLayerEditable(self, checked):
        
        layer = self.pluginGui.comboBox_layers.currentLayer()
        
        if layer is None:
            return 

        if checked:
            ok = layer.startEditing()
            if not ok:
                self.pluginGui.toggleEdit.setChecked(False)
                
        else:
            if not layer.isModified():
                layer.rollBack()
            else:
                retval = QMessageBox.warning(self.pluginGui, "Stop editting", "Do you want to save the changes to layer %s ?" % layer.name(), QMessageBox.Save | QMessageBox.Discard | QMessageBox.Cancel, QMessageBox.Save)

                if retval == QMessageBox.Save:
                    layer.commitChanges()
                elif retval == QMessageBox.Discard:
                    layer.rollBack()
    def reproject(self, vlist,  vectorlayer):
        renderer=self.canvas.mapRenderer()
        for i, point in enumerate(vlist):
            vlist[i]= renderer.layerToMapCoordinates(vectorlayer, QgsPointXY(point[0], point[1]))
        return vlist

    def saveConf(self):
        settings=QSettings()
        #settings.setValue("Geometry", QVariant(self.saveGeometry()))
        settings.setValue('/Plugin-cornici_viste/size',  self.pluginGui.size())
        settings.setValue('/Plugin-cornici_viste/position',  self.pluginGui.pos())
        settings.setValue('/Plugin-cornici_viste/inp_exp_dir', self.fPath)

    def sortedDict(self, adict):
        keys = adict.keys()
        keys.sort()
        return map(adict.get, keys)
